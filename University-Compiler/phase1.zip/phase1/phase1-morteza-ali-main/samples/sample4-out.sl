Line: 1 | Name: Incrementer | Number of ports: 2 | Number of component items: 1 | Number of repeat loops: 0
Line: 8 | Name: Multiplier | Number of ports: 3 | Number of component items: 1 | Number of repeat loops: 0
Line: 16 | Name: Top_Basic | Number of ports: 3 | Number of component items: 7 | Number of repeat loops: 4
Line: 23 | ComponentType: Incrementer | Instances: u_inc | Number of ports: 2
Line: 28 | ComponentType: Multiplier | Instances: u_mul | Number of ports: 3