Line: 1 | Name: FullAdder | Number of ports: 5 | Number of component items: 2 | Number of repeat loops: 0
Line: 12 | Name: AdderN | Number of ports: 5 | Number of component items: 5 | Number of repeat loops: 0
Line: 25 | Name: GEN_FA | Number of statements : 1
Line: 26 | ComponentType: FullAdder | Instances: fa | Number of ports: 5
Line: 37 | Name: Top_ParametricAdder | Number of ports: 3 | Number of component items: 4 | Number of repeat loops: 0
Line: 45 | ComponentType: AdderN | Instances: u_add8 | Number of ports: 5