Line: 1 | Name: matrix_multiplication | Number of ports: 0 | Number of component items: 14 | Number of repeat loops: 5
