Line: 3 | Name: FDRE | Number of ports: 5 | Number of component items: 0 | Number of repeat loops: 0
Line: 8 | Name: BUFG | Number of ports: 2 | Number of component items: 1 | Number of repeat loops: 0
Line: 12 | Name: CounterN | Number of ports: 3 | Number of component items: 5 | Number of repeat loops: 0
Line: 22 | Name: G | Number of statements : 1
Line: 23 | ComponentType: FDRE | Instances: ff | Number of ports: 5
Line: 30 | Name: Top_Counters | Number of ports: 5 | Number of component items: 5 | Number of repeat loops: 0
Line: 38 | ComponentType: BUFG | Instances: b0 | Number of ports: 2
Line: 39 | ComponentType: BUFG | Instances: b1 | Number of ports: 2
Line: 40 | ComponentType: CounterN | Instances: u0 | Number of ports: 3
Line: 41 | ComponentType: CounterN | Instances: u1 | Number of ports: 3
Line: 44 | Name: Scenario | Number of ports: 0 | Number of component items: 9 | Number of repeat loops: 6
Line: 48 | ComponentType: Top_Counters | Instances: dut | Number of ports: 5