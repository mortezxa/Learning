Line: 3 | Name: BUFG | Number of ports: 2 | Number of component items: 1 | Number of repeat loops: 0
Line: 7 | Name: Top_TimerBuf | Number of ports: 2 | Number of component items: 1 | Number of repeat loops: 0
Line: 8 | ComponentType: BUFG | Instances: u | Number of ports: 2
Line: 11 | Name: Scenario | Number of ports: 0 | Number of component items: 8 | Number of repeat loops: 4
Line: 15 | ComponentType: Top_TimerBuf | Instances: u0 | Number of ports: 2
Line: 16 | ComponentType: Top_TimerBuf | Instances: u1 | Number of ports: 2