/*
MIT License

Copyright (c) 2022 Mustafa Said Ağca

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// $antlr-format alignTrailingComments true, columnLimit 150, minEmptyLines 1, maxEmptyLinesToKeep 1, reflowComments false, useTab false
// $antlr-format allowShortRulesOnASingleLine false, allowShortBlocksOnASingleLine true, alignSemicolons hanging, alignColons hanging
grammar SimpleLang;
@header{
import main.ast.nodes.*;
import main.ast.nodes.Headers.*;
import main.ast.nodes.ComponentDeclaration.*;
import main.ast.nodes.ParameterPortList.*;
import main.ast.nodes.ListOfPortDeclarations.*;
import main.ast.nodes.ParameterPortDeclaration.*;
import main.ast.nodes.PortDirection.*;
import main.ast.nodes.ComponentItem.*;
import main.ast.nodes.ComponentItem.LoopStatement.*;
import main.ast.nodes.Expression.*;
}



source_text returns [SourceText SourceTextRet]
    :{$SourceTextRet= new SourceText();}
   ( cd=component_declaration{$SourceTextRet.addComponentDeclaration($cd.ComponentDeclarationRet);})* EOF
    ;

component_declaration returns [ComponentDeclaration ComponentDeclarationRet]
    : {$ComponentDeclarationRet=new ItemHeaderDeclaration();}
    ch=component_header{
    $ComponentDeclarationRet.setStartLine($ch.ComponentHeaderRet.getLine());
    ((ItemHeaderDeclaration)$ComponentDeclarationRet).setComponentHeader($ch.ComponentHeaderRet);
    }
    (ci=component_item
    {
    ((ItemHeaderDeclaration)$ComponentDeclarationRet).addComponentItem($ci.ComponentItemRet);
    })*
    (tx='endcomponenttype'
    {

    $ComponentDeclarationRet.setEndLine($tx.line);


    })
   ( cn=component_name{
   ((ItemHeaderDeclaration)$ComponentDeclarationRet).setComponentName($cn.ComponentNameRet);}
   )?
    |
    {$ComponentDeclarationRet=new IdentifierComponent();
    }
   (    ct1='componenttype'
    {

    $ComponentDeclarationRet.setStartLine($ct1.line);

    })
    (i=identifier{
   $ComponentDeclarationRet.setStartLine($e.line);
    ((IdentifierComponent)$ComponentDeclarationRet).setIdentifier($i.IdentifierRet);
    }) '(' '.*' ')' ';'
    (ci=component_item{
    ((IdentifierComponent)$ComponentDeclarationRet).addComponentItem($ci.ComponentItemRet);
    })*
   ( e='endcomponenttype'
   {
   $ComponentDeclarationRet.setEndLine($e.line);
   })
     (cn=component_name{((IdentifierComponent)$ComponentDeclarationRet).setComponentName($cn.ComponentNameRet);})?
      | { $ComponentDeclarationRet = new ConfigHeaderDeclaration(); }
          ch2=configuration_header
          {
              $ComponentDeclarationRet.setStartLine($ch2.ConfigurationHeaderRet.getLine());
              ((ConfigHeaderDeclaration)$ComponentDeclarationRet).setConfigurationHeader($ch2.ConfigurationHeaderRet);
          }
          (ci=component_item
          {
              ((ConfigHeaderDeclaration)$ComponentDeclarationRet).addComponentItem($ci.ComponentItemRet);
          })*
          (ec='endconfiguration'
          {
            $ComponentDeclarationRet.setEndLine($ec.line);
          })
          (cn=component_name
          {
              ((ConfigHeaderDeclaration)$ComponentDeclarationRet).setComponentName($cn.ComponentNameRet);
          })?
     | { $ComponentDeclarationRet = new ConfigDeclaration(); }
       c='configuration'
       {
        $ComponentDeclarationRet.setStartLine($c.line);
       }
       (i=identifier
       {
           ((ConfigDeclaration)$ComponentDeclarationRet).setIdentifier($i.IdentifierRet);
       })
       '(' '.*' ')' ';'
       (ci=component_item
       {
           ((ConfigDeclaration)$ComponentDeclarationRet).addComponentItem($ci.ComponentItemRet);
       })*
       (ec='endconfiguration'
       {
           $ComponentDeclarationRet.setEndLine($ec.line);
       })
       (cn=component_name
       {
           ((ConfigDeclaration)$ComponentDeclarationRet).setComponentName($cn.ComponentNameRet);
       })?
     ;

component_header returns [ComponentHeader ComponentHeaderRet]
    : { $ComponentHeaderRet = new ComponentHeader(); }
      ct='componenttype'
      id=identifier
      {
          $ComponentHeaderRet.setIdentifier($id.IdentifierRet);
          $ComponentHeaderRet.setLine($ct.line);
      }
      (pp=parameter_port_list
      {
          $ComponentHeaderRet.setParameterPortList($pp.ParameterPortListRet);
      })?
      (lp=list_of_port_declarations
      {
          $ComponentHeaderRet.setListOfPortDeclarations($lp.ListOfPortDeclarationsRet);
      })?
      ';'
    ;

configuration_header returns [ConfigurationHeader ConfigurationHeaderRet]
    : { $ConfigurationHeaderRet = new ConfigurationHeader(); }
      c='configuration'
      id=identifier
      {
          $ConfigurationHeaderRet.setIdentifier($id.IdentifierRet);
          $ConfigurationHeaderRet.setLine($c.line);
      }
      (pp=parameter_port_list
      {
          $ConfigurationHeaderRet.setParameterPortList($pp.ParameterPortListRet);
      })?
      (lp=list_of_port_declarations
      {
          $ConfigurationHeaderRet.setListOfPortDeclarations($lp.ListOfPortDeclarationsRet);
      })?
      ';'
    ;

component_name returns [ComponentName ComponentNameRet]
    : ':' (i=identifier{$ComponentNameRet=new ComponentName($i.IdentifierRet);})
    ;

parameter_port_list returns [ParameterPortList ParameterPortListRet]
     : { $ParameterPortListRet = new ListBased(); }
          h='#' '('
          la=list_of_param_assignments
          {
              ((ListBased)$ParameterPortListRet).setListOfParamAssignments($la.ListOfParamAssignmentsRet);
          }
          ( ',' pp=parameter_port_declaration
            {
                ((ListBased)$ParameterPortListRet).addParameterPortDeclaration($pp.ParameterPortDeclarationRet);
            }
          )*
          ')'
          {
              $ParameterPortListRet.setLine($h.line);
          }

    | { $ParameterPortListRet = new DeclarationBased(); }
          '#' '('
          pp1=parameter_port_declaration
          {
              ((DeclarationBased)$ParameterPortListRet).addParameterPortDeclaration($pp1.ParameterPortDeclarationRet);
          }
          ( ',' pp2=parameter_port_declaration
            {
                ((DeclarationBased)$ParameterPortListRet).addParameterPortDeclaration($pp2.ParameterPortDeclarationRet);
            }
          )*
          h=')'
          {
              $ParameterPortListRet.setLine($h.line);
          }
    | { $ParameterPortListRet = new EmptyBased(); }
            h='#' '(' ')'
            {
                $ParameterPortListRet.setLine($h.line);
            }
          ;


parameter_port_declaration returns [ParameterPortDeclaration ParameterPortDeclarationRet]

    :
      pd=parameter_declaration
      {
          $ParameterPortDeclarationRet=$pd.ParameterDeclarationRet;

      }


    | { $ParameterPortDeclarationRet = new ParameterAssignmentBased(); }
      dt=data_type
      {
          ((ParameterAssignmentBased)$ParameterPortDeclarationRet).setDataType($dt.DataTypeRet);
      }
      la=list_of_param_assignments
      {
          ((ParameterAssignmentBased)$ParameterPortDeclarationRet).setListOfParamAssignments($la.ListOfParamAssignmentsRet);
          // use the data_type line as the declaration line (adjust if you prefer another token)
          $ParameterPortDeclarationRet.setLine($dt.DataTypeRet.getLine());
      }
    ;


list_of_port_declarations returns [ListOfPortDeclarations ListOfPortDeclarationsRet]
    : { $ListOfPortDeclarationsRet = new ListOfPortDeclarations(); }
      lp='('
      pd1=port_decl
      {
          $ListOfPortDeclarationsRet.addPortDecl($pd1.PortDeclRet);
          $ListOfPortDeclarationsRet.setLine($lp.line);
      }
      (',' pd2=port_decl
      {
          $ListOfPortDeclarationsRet.addPortDecl($pd2.PortDeclRet);
      })*
      ')'
    | { $ListOfPortDeclarationsRet = new ListOfPortDeclarations(); }
      lp='(' ')'
      {
          $ListOfPortDeclarationsRet.setLine($lp.line);
      }
    ;
    port_decl returns [PortDecl PortDeclRet]
        :{$PortDeclRet=new PortDecl();}
        port_prefix port_direction? data_type? identifier ('=' constant_expression)?
        | port_prefix port_direction? implicit_data_type identifier unpacked_dimension* (
            '=' constant_expression
        )?
        | port_prefix port_direction? net_type data_type_or_implicit? identifier unpacked_dimension* (
            '=' constant_expression
        )?
        ;


port_direction returns [PortDirection PortDirectionRet]
    :
      i='in'
      {
        $PortDirectionRet= new InPortDirection($i.text,$i.line);
      }
    |
      o='out'
      {
          $PortDirectionRet = new OutPortDirection($o.text,$o.line);
      }
    ;


port_prefix returns [PortPrefix PortPrefixRet]
    : p='port'
      {
          $PortPrefixRet = new PortPrefix($p.text, $p.line);}

    ;

component_item returns [ComponentItem ComponentItemRet]

        : cc=component_common_item
          {
              $ComponentItemRet = $cc.ComponentCommonItemRet;
          }
        | cd=component_declaration
          {
              $ComponentItemRet = $cd.ComponentDeclarationRet;
          }
        | ls=loop_statement
          {
              $ComponentItemRet = $ls.LoopStatementRet;

          }
        ;


component_common_item returns [ComponentCommonItem ComponentCommonItemRet]
    :
     component_item_declaration
    | component_program_interface_instantiation
    | continuous_set
    ;

component_item_declaration
    : net_declaration
    | parameter_declaration ';'
    | ';'
    ;

parameter_declaration returns [ParameterDeclaration ParameterDeclarationRet]
    : {$ParameterDeclarationRet = new ParameterDeclaration();}
    'parameter' data_type_or_implicit? list_of_param_assignments
    ;

net_declaration
    : net_type data_type_or_implicit? list_of_net_decl_assignments ';'
    | identifier list_of_net_decl_assignments ';'
    ;

data_type returns [DataType DataTypeRet]
    :{$DataTypeRet = new DataType();}
     integer_type signing? packed_dimension*
    | non_integer_type
    | 'string'
    | identifier packed_dimension+
    ;

data_type_or_implicit
    : data_type
    | implicit_data_type
    ;

implicit_data_type
    : packed_dimension+
    | signing packed_dimension*
    ;

integer_type
    : integer_vector_type
    | integer_atom_type
    ;

integer_atom_type
    : 'byte'
     | 'shortint' | 'int' | 'longint' | 'integer' | 'time';


integer_vector_type
    : 'bit' | 'data';

non_integer_type
    : 'shortreal' | 'real';

net_type
    : 'data';

signing
    : 'signed' | 'unsigned';

simple_type
    : integer_type
    | non_integer_type
    | identifier
    ;

list_of_net_decl_assignments
    : net_decl_assignment (',' net_decl_assignment)*
    ;

list_of_param_assignments returns [ListOfParamAssignments ListOfParamAssignmentsRet]
    :{$ListOfParamAssignmentsRet=new ListOfParamAssignments();}
    param_assignment (',' param_assignment)*
    ;

net_decl_assignment
    : identifier unpacked_dimension* ('=' expression)?
    ;

param_assignment
    : identifier unpacked_dimension* ('=' constant_param_expression)?
    ;

unpacked_dimension
    : '[' constant_range ']'
    | '[' constant_expression ']'
    ;

packed_dimension
    : '[' constant_range ']'
    | unsized_dimension
    ;

unsized_dimension
    : '[' ']'
    ;


block_label returns [BlockLabel BlockLabelRet]
    : { $BlockLabelRet = new BlockLabel(); }
      id=identifier
      ':'
      {
          $BlockLabelRet.setIdentifier($id.IdentifierRet);
          $BlockLabelRet.setLine($id.IdentifierRet.getLine());
      }
    ;

component_program_interface_instantiation
    : identifier parameter_value_assignment? hierarchical_instance (
        ',' hierarchical_instance
    )* ';'
    ;

parameter_value_assignment
    : '#' '(' list_of_parameter_assignments? ')'
    ;

list_of_parameter_assignments
    : param_expression (',' param_expression)*
    | named_parameter_assignment ( ',' named_parameter_assignment)*
    ;

named_parameter_assignment
    : '.' identifier '(' param_expression? ')'
    ;

hierarchical_instance
    : name_of_instance '(' list_of_port_connections ')'
    ;

name_of_instance
    : identifier unpacked_dimension*
    ;

list_of_port_connections
    : named_port_connection ( ',' named_port_connection)*
    ;

named_port_connection
    : '.' identifier port_assign?
    | '.*'
    ;

port_assign
    : '(' expression? ')'
    ;


continuous_set returns [ContinuousSet ContinuousSetRet]
    : { $ContinuousSetRet = new ContinuousSet(); }
      s='set'
      la=list_of_net_assignments
      {
          $ContinuousSetRet.setListOfNetAssignments($la.ListOfNetAssignmentsRet);
          $ContinuousSetRet.setLine($s.line);
      }
      ';'
    ;

procedural_continuous_set
    : 'set' variable_assignment
    ;

list_of_net_assignments returns [ListOfNetAssignments ListOfNetAssignmentsRet]
    : net_assignment (',' net_assignment)*
    ;

net_assignment
    : net_lvalue '=' expression
    ;

operator_assignment
    : variable_lvalue assignment_operator expression
    ;

assignment_operator
    : '=' | '+=' | '-=' | '*=' | '/=' | '%=' | '&=' | '|=' | '^=' | '<<=' | '>>=' | '<<<=' | '>>>=' ;

nonblocking_assignment
    : variable_lvalue '<=' expression
    ;

variable_assignment
    : variable_lvalue '=' expression
    ;

statement_or_null returns [StatementOrNull StatementOrNullRet]
    : statement
    |';'
    ;

statement
    : block_label? statement_item
    ;

statement_item
    : operator_assignment ';'
    | nonblocking_assignment ';'
    | procedural_continuous_set ';'
    | conditional_statement
    | inc_or_dec_expression ';'
    | subroutine_call_statement
    | loop_statement
    ;

conditional_statement
    : 'if' '(' cond_predicate ')' statement_or_null ('else' statement_or_null)?
    ;

cond_predicate
    : expression ('&&&' expression)*
    ;


loop_statement returns [LoopStatement LoopStatementRet]
    :
      {
          $LoopStatementRet = new ForeverLoop();
      }
      f='forever' stmt=statement_or_null
      {
          ((ForeverLoop)$LoopStatementRet).setStatementOrNull($stmt.StatementOrNullRet);
          $LoopStatementRet.setLine($f.line);
      }
    |
      {
          $LoopStatementRet = new RepeatLoop();
      }
      r='repeat' '(' exp=expression ')' period=period_declaration stmt=statement_or_null
      {
          ((RepeatLoop)$LoopStatementRet).setExpression($exp.ExpressionRet);
          ((RepeatLoop)$LoopStatementRet).setPeriodDeclaration($period.PeriodDeclarationRet);
          ((RepeatLoop)$LoopStatementRet).setStatementOrNull($stmt.StatementOrNullRet);
          $LoopStatementRet.setLine($r.getLine());
      }
    |
      {
          $LoopStatementRet = new WhileLoop();
      }
      d='do' stmt=statement_or_null 'while' '(' exp=expression ')' ';'
      {
          ((WhileLoop)$LoopStatementRet).setExpression($exp.ExpressionRet);
          ((WhileLoop)$LoopStatementRet).setStatementOrNull($stmt.StatementOrNullRet);
          $LoopStatementRet.setLine($d.line);
      }
    ;

period_declaration returns [PeriodDeclaration PeriodDeclarationRet]
    :{$PeriodDeclarationRet=new PeriodDeclaration();} 'period' '=' expression;

subroutine_call_statement
    : subroutine_call ';'
    | 'void' '\'' '(' subroutine_call ')' ';'
    ;

concatenation
    : '{' expression (',' expression)* '}'
    | '{' '}'
    ;

constant_concatenation
    : '{' constant_expression (',' constant_expression)* '}'
    ;

arg_list
    : '(' list_of_arguments ')'
    ;

subroutine_call
    : identifier arg_list?
    ;

list_of_arguments
    : ordered_arg (',' ordered_arg)* (',' named_arg)*
    | named_arg ( ',' named_arg)*
    ;

ordered_arg
    : expression?
    ;

named_arg
    : '.' identifier '(' expression? ')'
    ;

inc_or_dec_expression
    : inc_or_dec_operator variable_lvalue
    | variable_lvalue inc_or_dec_operator
    ;

constant_expression
    : constant_primary
    | unary_operator constant_primary
    | constant_expression '**' constant_expression
    | constant_expression ('*' | '/' | '%') constant_expression
    | constant_expression ( '+' | '-') constant_expression
    | constant_expression ('>>' | '<<' | '>>>' | '<<<') constant_expression
    | constant_expression ('<' | '<=' | '>' | '>=') constant_expression
    | constant_expression ('==' | '!=' | '===' | '!==' | '==?' | '!=?') constant_expression
    | constant_expression '&' constant_expression
    | constant_expression ('^' | '^~' | '~^') constant_expression
    | constant_expression '|' constant_expression
    | constant_expression '&&' constant_expression
    | constant_expression '||' constant_expression
    | <assoc = right> constant_expression '?' constant_expression ':' constant_expression
    ;

constant_mintypmax_expression
    : constant_expression (':' constant_expression ':' constant_expression)?
    ;

constant_param_expression
    : constant_mintypmax_expression
    | data_type
    ;

param_expression
    : mintypmax_expression
    | data_type
    ;

constant_range
    : constant_expression ':' constant_expression
    ;

expression returns [Expression ExpressionRet]
    : primary
    | '(' operator_assignment ')'
    | unary_operator primary
    | inc_or_dec_expression
    | expression '**' expression
    | expression ( '*' | '/' | '%') expression
    | expression ( '+' | '-') expression
    | expression ( '>>' | '<<' | '>>>' | '<<<') expression
    | expression (
        ( '<' | '<=' | '>' | '>=') expression
    )
    |  expression ('==' | '!=' | '===' | '!==' | '==?' | '!=?') expression
    |  expression '&' expression
    |  expression ( '^' | '^~' | '~^') expression
    |  expression '|' expression
    |  expression '&&' expression
    |  expression '||' expression
    |  <assoc = right> expression '?' expression ':' expression
    ;


mintypmax_expression
    : expression (':' expression ':' expression)?
    ;

part_select_range
    : constant_range
    ;


constant_primary
    : primary_literal
    | identifier constant_select?
    | constant_concatenation
    | identifier (arg_list)
    | '(' constant_mintypmax_expression ')'
    | constant_primary '\'' '(' constant_expression ')'
    | (simple_type | signing | 'string' | 'const') '\'' '(' constant_expression ')'
    | 'null'
    ;

primary
    : primary_literal
    | hierarchical_identifier select_?
    | concatenation
    | identifier (arg_list)
    | '(' mintypmax_expression ')'
    | primary '\'' '(' expression ')'
    | (integer_type | non_integer_type | signing | 'string' | 'const') '\'' '(' expression ')'
    ;

primary_literal
    : number
    | time_literal
    | unbased_unsized_literal
    | string_literal
    ;

bit_select
    : ('[' expression ']')+
    ;

select_
    : '[' part_select_range ']'
    | bit_select ( '[' part_select_range ']')?
    ;

constant_bit_select
    : ('[' constant_expression ']')+
    ;

constant_select
    :  constant_bit_select
    ;

net_lvalue
    : identifier constant_select?
    | '{' net_lvalue ( ',' net_lvalue)* '}'
    ;

variable_lvalue
    : hierarchical_identifier select_?
    | '{' variable_lvalue ( ',' variable_lvalue)* '}'
    ;

unary_operator
    : '+' | '-' | '!' | '~' | '&' | '~&' | '|' | '~|' | '^' | '~^' | '^~';

inc_or_dec_operator
    : '++' | '--';

number
    : integral_number
    | real_number
    ;

integral_number
    : decimal_number
    | binary_number
    ;

decimal_number
    : size? decimal_base
    | unsigned_number
    ;

binary_number
    : size? binary_base
    ;

time_literal
    : TIME_LITERAL
    ;

size
    : UNSIGNED_NUMBER
    ;

real_number
    : FIXED_POINT_NUMBER
    | EXPONENTIAL_NUMBER
    ;

unsigned_number
    : UNSIGNED_NUMBER
    ;

decimal_base
    : DECIMAL_BASE
    ;

binary_base
    : BINARY_BASE
    ;

unbased_unsized_literal
    : UNBASED_UNSIZED_LITERAL
    ;

string_literal
    : STRING_LITERAL
    ;

identifier returns [Identifier IdentifierRet]
    : (s=SIMPLE_IDENTIFIER{$IdentifierRet=new Identifier($s.text,$s.line);})
    | (e=ESCAPED_IDENTIFIER{$IdentifierRet=new Identifier($e.text,$e.line);})
    ;

hierarchical_identifier
    : identifier
    ;

// LEXER RULES
AND                 : 'and';
BIT                 : 'bit';
BREAK               : 'break';
BUF                 : 'buf';
BUFIFONE            : 'bufif1';
BUFIFZERO           : 'bufif0';
BYTE                : 'byte';
CASE                : 'case';
CASEX               : 'casex';
CASEZ               : 'casez';
COMPONENTTYPE       : 'componenttype';
CHANDLE             : 'chandle';
CLOCKING            : 'clocking';
CONFIGURATION       : 'configuration';
CONST               : 'const';
CONTEXT             : 'context';
CONTINUE            : 'continue';
CROSS               : 'cross';
DATA                : 'data';
DEFAULT             : 'default';
DESIGN              : 'design';
DO                  : 'do';
EDGE                : 'edge';
ELSE                : 'else';
ENDCASE             : 'endcase';
ENDCOMPONENTTYPE    : 'endcomponenttype';
ENDCONFIGURATION    : 'endconfiguration';
ENDDO               : 'enddo';
ENDEXPAND           : 'endexpand';
ENDPRIMITIVE        : 'endprimitive';
ENDPROGRAM          : 'endprogram';
ENUM                : 'enum';
EVENT               : 'event';
EXPAND              : 'expand';
FOR                 : 'for';
FOREACH             : 'foreach';
FOREVER             : 'forever';
GLOBAL              : 'global';
HIGHZONE            : 'highz1';
HIGHZZERO           : 'highz0';
IF                  : 'if';
IFF                 : 'iff';
IFNONE              : 'ifnone';
IN                  : 'in';
INCLUDE             : 'include';
INDEX               : 'index';
INOUT               : 'inout';
INSTANCE            : 'instance';
INT                 : 'int';
INTEGER             : 'integer';
INTERCONNECT        : 'interconnect';
LARGE               : 'large';
LOCAL               : 'local';
LOCALPARAM          : 'localparam';
LONGINT             : 'longint';
MEDIUM              : 'medium';
MODPORT             : 'modport';
NAND                : 'nand';
NEGEDGE             : 'negedge';
NETTYPE             : 'nettype';
NEW                 : 'new';
NOR                 : 'nor';
NOT                 : 'not';
NOTIFONE            : 'notif1';
NOTIFZERO           : 'notif0';
NULL                : 'null';
OR                  : 'or';
OUT                 : 'out';
PACKED              : 'packed';
PARAMETER           : 'parameter';
POSEDGE             : 'posedge';
PORT                : 'port';
PRIMITIVE           : 'primitive';
PROTECTED           : 'protected';
PULLDOWN            : 'pulldown';
PULLONE             : 'pull1';
PULLUP              : 'pullup';
PULLZERO            : 'pull0';
PURE                : 'pure';
REAL                : 'real';
REF                 : 'ref';
RELEASE             : 'release';
REPEAT              : 'repeat';
RESTRICT            : 'restrict';
RETURN              : 'return';
SAMPLE              : 'sample';
SET                 : 'set';
SHORTINT            : 'shortint';
SHORTREAL           : 'shortreal';
SIGNED              : 'signed';
SMALL               : 'small';
SOFT                : 'soft';
SOLVE               : 'solve';
STATIC              : 'static';
STD                 : 'std';
STRING              : 'string';
STRONG              : 'strong';
STRONGONE           : 'strong1';
STRONGZERO          : 'strong0';
STRUCT              : 'struct';
SUPER               : 'super';
TAGGED              : 'tagged';
THIS                : 'this';
TIME                : 'time';
TIMEPRECISION       : 'timeprecision';
TIMESCALE           : 'timescale';
TIMEUNIT            : 'timeunit';
TYPE                : 'type';
TYPEDEF             : 'typedef';
UNION               : 'union';
UNIQUE              : 'unique';
UNIQUEZERO          : 'unique0';
UNSIGNED            : 'unsigned';
UNTYPED             : 'untyped';
VAR                 : 'var';
VECTORED            : 'vectored';
VIRTUAL             : 'virtual';
VOID                : 'void';
WHILE               : 'while';
WILDCARD            : 'wildcard';
WITH                : 'with';
XNOR                : 'xnor';
XOR                 : 'xor';

AM       : '&';
AMAM     : '&&';
AMAMAM   : '&&&';
AMEQ     : '&=';
AP       : '\'';
AS       : '*';
ASAS     : '**';
ASEQ     : '*=';
ASGT     : '*>';
AT       : '@';
ATAT     : '@@';
CA       : '^';
CAEQ     : '^=';
CATI     : '^~';
CL       : ':';
CLCL     : '::';
CLEQ     : ':=';
CLSL     : ':/';
CO       : ',';
DL       : '$';
DQ       : '"';
DT       : '.';
DTAS     : '.*';
EM       : '!';
EMEQ     : '!=';
EMEQEQ   : '!==';
EMEQQM   : '!=?';
EQ       : '=';
EQEQ     : '==';
EQEQEQ   : '===';
EQEQQM   : '==?';
EQGT     : '=>';
GA       : '`';
GT       : '>';
GTEQ     : '>=';
GTGT     : '>>';
GTGTEQ   : '>>=';
GTGTGT   : '>>>';
GTGTGTEQ : '>>>=';
HA       : '#';
HAEQHA   : '#=#';
HAHA     : '##';
HAMIHA   : '#-#';
LB       : '[';
LC       : '{';
LP       : '(';
LT       : '<';
LTEQ     : '<=';
LTLT     : '<<';
LTLTEQ   : '<<=';
LTLTLT   : '<<<';
LTLTLTEQ : '<<<=';
LTMIGT   : '<->';
MI       : '-';
MICL     : '-:';
MIEQ     : '-=';
MIGT     : '->';
MIGTGT   : '->>';
MIMI     : '--';
MO       : '%';
MOEQ     : '%=';
PL       : '+';
PLCL     : '+:';
PLEQ     : '+=';
PLPL     : '++';
QM       : '?';
RB       : ']';
RC       : '}';
RP       : ')';
SC       : ';';
SL       : '/';
SLEQ     : '/=';
TI       : '~';
TIAM     : '~&';
TICA     : '~^';
TIVL     : '~|';
VL       : '|';
VLEQ     : '|=';
VLEQGT   : '|=>';
VLMIGT   : '|->';
VLVL     : '||';

fragment ASCII_ANY        : [\u0000-\u007f];
fragment ASCII_NO_NEWLINE : [\u0000-\u0009\u000b-\u000c\u000e-\u007f];
fragment ASCII_NO_NEWLINE_QUOTE_BACKSLASH:
    [\u0000-\u0009\u000b-\u000c\u000e-\u0021\u0023-\u005b\u005d-\u007f]
;
fragment ASCII_NO_NEWLINE_QUOTE_SLASH_BACKSLASH_GRAVE_ACCENT:
    [\u0000-\u0009\u000b-\u000c\u000e-\u0021\u0023-\u002e\u0030-\u005b\u005d-\u005f\u0061-\u007f]
;
fragment ASCII_NO_PARENTHESES        : [\u0000-\u0027\u002a-\u007f];
fragment ASCII_NO_SLASH_GRAVE_ACCENT : [\u0000-\u002e\u0030-\u005f\u0061-\u007f];
fragment ASCII_PRINTABLE             : [\u0020-\u007e];
fragment ASCII_PRINTABLE_NO_QUOTE_ANGLE_BRACKETS_BACKSLASH:
    [\u0020-\u0021\u0023-\u003b\u003d\u003f-\u005b\u005d-\u007e]
;
fragment ASCII_PRINTABLE_NO_SPACE : [\u0021-\u007e];
fragment CHAR_HEX                 : [0-9a-fA-F] [0-9a-fA-F]?;
fragment CHAR_OCTAL               : [0-7] [0-7]? [0-7]?;
fragment ESC_ASCII_NO_NEWLINE     : '\\' ASCII_NO_NEWLINE;
fragment ESC_ASCII_PRINTABLE      : '\\' ASCII_PRINTABLE;
fragment ESC_NEWLINE              : '\\' '\r'? '\n';
fragment ESC_SPECIAL_CHAR         : '\\' ( [nt\\"vfa] | CHAR_HEX | CHAR_OCTAL);
fragment IDENTIFIER               : ESCAPED_IDENTIFIER | SIMPLE_IDENTIFIER;
fragment MACRO_ARGS               : '(' ( MACRO_ARGS | ASCII_NO_PARENTHESES)* ')';
fragment SPACE_TAB                : [ \t]+;

BLOCK_COMMENT           : '/*' ASCII_ANY*? '*/' -> channel(HIDDEN);
LINE_COMMENT            : ('//' | '--') ASCII_NO_NEWLINE* -> channel(HIDDEN);
ESCAPED_IDENTIFIER      : '\\' ASCII_PRINTABLE_NO_SPACE* [ \t\r\n];
EXPONENTIAL_NUMBER      : UNSIGNED_NUMBER ( '.' UNSIGNED_NUMBER)? [eE] [+\-]? UNSIGNED_NUMBER;
FIXED_POINT_NUMBER      : UNSIGNED_NUMBER '.' UNSIGNED_NUMBER;
SIMPLE_IDENTIFIER       : [a-zA-Z_] [a-zA-Z0-9_$]*;
STRING_LITERAL          : '"' ( ASCII_NO_NEWLINE_QUOTE_BACKSLASH | ESC_NEWLINE | ESC_SPECIAL_CHAR)* '"';
SYSTEM_TF_IDENTIFIER    : '$' [a-zA-Z0-9_$] [a-zA-Z0-9_$]*;
TIME_LITERAL            : UNSIGNED_NUMBER ( '.' UNSIGNED_NUMBER)? [munpf]? 's';
UNBASED_UNSIZED_LITERAL : '\'0' | '\'1' | '\'' [xXzZ];
UNSIGNED_NUMBER         : [0-9] [0-9_]*;
WHITE_SPACE             : [ \t\r\n]+ -> channel(HIDDEN);
NEWLINE                  : '\r'? '\n' -> channel(HIDDEN);
ZERO_OR_ONE_X_OR_Z      : [01] [xXzZ];

BINARY_BASE             : '\'' [sS]? [bB] [01xXzZ?] [01xXzZ?_]*;
DECIMAL_BASE            : '\'' [sS]? [dD] ([0-9] [0-9_]* | [xXzZ?] '_'*);
OCTAL_BASE              : '\'' [sS]? [oO] [0-7xXzZ?] [0-7xXzZ?_]*;
HEX_BASE                : '\'' [sS]? [hH] [0-9a-fA-FxXzZ?] [0-9a-fA-FxXzZ?_]*;

TIMESCALE_DIRECTIVE     : GA TIMESCALE
                        [ \t]* BLOCK_COMMENT* [ \t]*
                        UNSIGNED_NUMBER
                        [ \t]* BLOCK_COMMENT* [ \t]*
                        [munpf]? 's'
                        [ \t]* BLOCK_COMMENT* [ \t]*
                        SL
                        [ \t]* BLOCK_COMMENT* [ \t]*
                        UNSIGNED_NUMBER
                        [ \t]* BLOCK_COMMENT* [ \t]*
                        [munpf]? 's'
                        [ \t]* BLOCK_COMMENT* [ \t]* -> channel(HIDDEN);
