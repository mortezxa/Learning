package main.visitor;

import main.ast.nodes.*;
import main.ast.nodes.ComponentDeclaration.*;
import main.ast.nodes.ComponentItem.ComponentItem;
import main.ast.nodes.ComponentItem.GenerateItem.GenerateItem;
import main.ast.nodes.ComponentItem.GenerateRegion;
import main.ast.nodes.ComponentItem.LoopStatement.LoopStatement;
import main.ast.nodes.ComponentItem.LoopStatement.*;
import main.ast.nodes.Headers.*;

import main.ast.nodes.ListOfPortDeclarations.*;
import main.ast.nodes.ParameterPortDeclaration.ParameterPortDeclaration;
import main.ast.nodes.ParameterPortList.*;
import main.ast.nodes.ParameterPortDeclaration.*;
import main.ast.nodes.PortDirection.*;
import main.ast.nodes.RepeatLoop;

public interface IVisitor<T> {

    T visit(SourceText sourceText);

    T visit(ComponentDeclaration componentDeclaration);

    T visit(ComponentHeader componentHeader);

    T visit(ConfigurationHeader configurationHeader);

    T visit(Identifier identifier);

    T visit(ComponentName componentName);

    T visit(ItemHeaderDeclaration itemHeaderDeclaration);

    T visit(ComponentItem componentItem);

    T visit(IdentifierComponent identifierComponent);

    // New ones:
    T visit(ConfigHeaderDeclaration configHeaderDeclaration);

    T visit(ConfigDeclaration configDeclaration);

    T visit(DeclarationBased declarationBased);

    T visit(EmptyBased emptyBased);

    T visit(ListBased listBased);
    T visit(ListOfParamAssignments listOfParamAssignments);
    T visit(ParameterPortDeclaration parameterPortDeclaration);
    T visit(PortDecl portDecl);
    T visit(ListOfPortDeclarations listOfPortDeclarations);


    T visit(ParameterAssignmentBased parameterAssignmentBased);

    T visit(DataType dataType);
    T visit(ParameterDeclaration parameterDeclaration);
    T visit(PortDirection portDirection);

    T visit(InPortDirection inPortDirection);

    T visit(OutPortDirection outPortDirection);

    T visit(PortPrefix portPrefix);
    T visit(GenvarDeclaration genvarDeclaration);
    T visit(GenerateRegion generateRegion);
    T visit(GenerateItem generateItem);
    T visit(BlockLabel blockLabel);
    T visit(ContinuousSet continuousSet);
    T visit(LoopStatement loopStatement);

    T visit(WhileLoop whileLoop);

    T visit(ForeverLoop foreverLoop);

    T visit(RepeatLoop repeatLoop);

}
