package main.visitor;

import main.ast.nodes.*;
import main.ast.nodes.ComponentDeclaration.*;
import main.ast.nodes.ComponentItem.LoopStatement.ForeverLoop;
import main.ast.nodes.ComponentItem.LoopStatement.LoopStatement;
import main.ast.nodes.ComponentItem.LoopStatement.WhileLoop;
import main.ast.nodes.Headers.*;

import main.ast.nodes.ListOfPortDeclarations.*;
import main.ast.nodes.ParameterPortDeclaration.*;
import main.ast.nodes.PortDirection.*;
//import main.ast.nodes.ParameterPortDeclaration.ParameterPortDeclaration;
import main.ast.nodes.ParameterPortList.*;
import main.ast.nodes.ComponentItem.GenerateItem.*;
import main.ast.nodes.ComponentItem.*;
import main.ast.nodes.RepeatLoop;

public abstract class Visitor<T> implements IVisitor<T> {

    @Override
    public T visit(SourceText sourceText) { return null; }

    @Override
    public T visit(Identifier identifier) { return null; }

    @Override
    public T visit(ComponentDeclaration componentDeclaration) { return null; }

    @Override
    public T visit(ComponentHeader componentHeader) { return null; }

    @Override
    public T visit(ConfigurationHeader configurationHeader) { return null; }

    @Override
    public T visit(ComponentName componentName) { return null; }

    @Override
    public T visit(ItemHeaderDeclaration itemHeaderDeclaration) { return null; }

//    @Override
//    public T visit(ComponentItem componentItem) { return null; }

    @Override
    public T visit(IdentifierComponent identifierComponent) { return null; }


    @Override
    public T visit(ConfigHeaderDeclaration configHeaderDeclaration) { return null; }

    @Override
    public T visit(ConfigDeclaration configDeclaration) { return null; }

    @Override
    public T visit(DeclarationBased declarationBased) { return null; }

    @Override
    public T visit(EmptyBased emptyBased) { return null; }

    @Override
    public T visit(ListBased listBased) { return null; }

    @Override
    public T visit(ListOfParamAssignments listOfParamAssignments) { return null; }

    @Override
    public T visit(ParameterPortDeclaration parameterPortDeclaration) { return null; }

    @Override
   public T visit(PortDecl portDecl){return null;}

    @Override
    public T visit(ListOfPortDeclarations listOfPortDeclarations) { return null; }
    // abstract base
//


    @Override
    public T visit(ParameterAssignmentBased parameterAssignmentBased) { return null; }

    @Override
    public T visit(DataType dataType) { return null; }

    @Override
    public T visit(ParameterDeclaration parameterDeclaration) { return null; }
    @Override
    public T visit(PortDirection portDirection) { return null; }

    @Override
    public T visit(InPortDirection inPortDirection) { return null; }

    @Override
    public T visit(OutPortDirection outPortDirection) { return null; }
    @Override
    public T visit(PortPrefix portPrefix) {
        return null;
    }
    @Override
    public T visit(GenerateRegion generateRegion) {
        return null;
    }

    @Override
    public T visit(GenerateItem generateItem) {
        return null;
    }
    @Override
    public T visit(GenvarDeclaration genvarDeclaration) {
        return null;
    }
    @Override
    public T visit(BlockLabel blockLabel) {
        return null;
    }
    @Override
    public T visit(ContinuousSet continuousSet) {
        return null;
    }
    @Override
    public T visit(LoopStatement loopStatement){return null;}
    @Override
    public T visit(WhileLoop whileLoop){return null;}
    @Override
    public T visit(ForeverLoop foreverLoop){return null;}
    @Override
    public T visit(RepeatLoop repeatLoop){return null;}
    @Override
    public T visit(ComponentItem componentItem){return null;}




}
