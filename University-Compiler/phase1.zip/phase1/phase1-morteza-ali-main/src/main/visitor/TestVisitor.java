package main.visitor;

import main.ast.nodes.*;
import main.ast.nodes.ComponentDeclaration.*;
import main.ast.nodes.Expression.*;
import main.ast.nodes.PortDirection.*;
import main.ast.nodes.ListOfPortDeclarations.*;
import main.ast.nodes.ComponentItem.*;

import java.util.List;

public class TestVisitor extends Visitor<Void> {

    @Override
    public Void visit(SourceText sourceText) {
        for (ComponentDeclaration componentDeclaration : sourceText.getComponentDeclarationList()) {
            componentDeclaration.accept(this);
        }
        return null;
    }
    @Override
    public Void visit(ItemHeaderDeclaration itemHeaderDeclaration) {
        itemHeaderDeclaration.getComponentHeader().accept(this);
        for (ComponentItem componentItem : itemHeaderDeclaration.getComponentItemList()) {
            if(componentItem!=null){
                componentItem.accept(this);
            }

        }
        System.out.println(" number of component Item is : " +itemHeaderDeclaration.getComponentItemList().size());
        return null;
    }
    @Override
    public Void visit(IdentifierComponent identifierComponent) {
        identifierComponent.getIdentifier().accept(this);
        for (ComponentItem componentItem : identifierComponent.getComponentItemList()) {
            if(componentItem!=null){
                componentItem.accept(this);
            }
        }
        return null;
    }
    @Override
    public Void visit(ConfigHeaderDeclaration configHeaderDeclaration) {
        configHeaderDeclaration.getConfigurationHeader().accept(this);
        for (ComponentItem componentItem : configHeaderDeclaration.getComponentItemList()) {
            if(componentItem!=null){
                componentItem.accept(this);
            }
        }
        return null;
    }}