package main.ast.nodes;

public class ListOfGenvarIdentifiers {
}
