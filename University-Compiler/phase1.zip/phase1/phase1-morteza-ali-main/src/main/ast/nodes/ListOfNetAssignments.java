package main.ast.nodes;

public class ListOfNetAssignments {
}
