package main.ast.nodes.ParameterPortDeclaration;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public class ParameterPortDeclaration extends Node {
    public ParameterPortDeclaration() {
    }

    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
