package main.ast.nodes;

import main.visitor.IVisitor;

public class ListOfParamAssignments extends  Node{
    public ListOfParamAssignments() {

    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
