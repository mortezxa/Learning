package main.ast.nodes;

import main.visitor.IVisitor;

public class DataType extends  Node{
    public DataType() {

    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
