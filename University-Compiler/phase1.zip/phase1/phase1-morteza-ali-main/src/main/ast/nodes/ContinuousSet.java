package main.ast.nodes;

import main.visitor.IVisitor;

/**
 * AST node for a continuous set statement:
 *     set <list_of_net_assignments> ;
 *
 * Follows the same conventions as the other AST nodes in your project.
 */
public class ContinuousSet extends Node {

    private ListOfNetAssignments listOfNetAssignments;
    private int line;

    public ContinuousSet() {
        // no-op
    }

    public void setListOfNetAssignments(ListOfNetAssignments listOfNetAssignments) {
        this.listOfNetAssignments = listOfNetAssignments;
    }

    public ListOfNetAssignments getListOfNetAssignments() {
        return listOfNetAssignments;
    }



    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }


}
