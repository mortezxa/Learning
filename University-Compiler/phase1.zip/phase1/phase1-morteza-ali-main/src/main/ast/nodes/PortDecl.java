package main.ast.nodes;

import main.ast.nodes.ComponentDeclaration.ComponentDeclaration;
import main.visitor.IVisitor;

import java.util.ArrayList;
import java.util.List;

public class PortDecl extends Node{
    List<ComponentDeclaration> componentDeclarationList;

    public PortDecl() {
        this.componentDeclarationList = new ArrayList<>();
    }


    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
