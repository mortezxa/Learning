package main.ast.nodes;

import main.visitor.IVisitor;

public class Identifier extends Node {
    public Identifier(String name,int line) {
         this.name=name;
        this.line=line;
    }
    int line;
    String name;
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
