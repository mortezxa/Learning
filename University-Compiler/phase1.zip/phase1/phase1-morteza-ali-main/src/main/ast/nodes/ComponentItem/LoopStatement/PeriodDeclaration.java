package main.ast.nodes.ComponentItem.LoopStatement;

public class PeriodDeclaration {
}
