package main.ast.nodes;

import main.ast.nodes.ParameterPortDeclaration.ParameterPortDeclaration;
import main.visitor.IVisitor;

public class ParameterDeclaration extends ParameterPortDeclaration {
    public ParameterDeclaration() {

    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
