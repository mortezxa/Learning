configuration UninitializedVariable_1;
  data x;
  data y = 0;

  set y = x + 1;
endconfiguration
