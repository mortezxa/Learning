configuration MissingComponent;
  data a = 0;
  data y = 0;

  NoSuchComponent u0(.A(a), .Y(y));
  
endconfiguration
