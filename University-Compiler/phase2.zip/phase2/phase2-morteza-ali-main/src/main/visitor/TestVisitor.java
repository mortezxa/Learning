/*
MIT License

Copyright (c) 2022 Mustafa Said ""

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

package main.visitor;

import main.ast.nodes.*;
import main.ast.nodes.Headers.*;
import main.ast.nodes.ComponentDeclaration.*;
import main.ast.nodes.ParameterPortList.*;
import main.ast.nodes.ParameterPortDeclaration.*;
import main.ast.nodes.PortDecl.*;
import main.ast.nodes.PortDirection.*;
import main.ast.nodes.ComponentItem.*;
import main.ast.nodes.ComponentItem.Dimension.*;
import main.ast.nodes.ComponentItem.LoopStatement.*;
import main.ast.nodes.ComponentItem.NetDeclaration.*;
import main.ast.nodes.ComponentItem.GenerateItem.*;
import main.ast.nodes.ComponentItem.ListOfPortConnections.*;
import main.ast.nodes.Expression.*;
import main.ast.nodes.Types.*;
import main.ast.nodes.ListOfParameterAssignments.*;
import main.ast.nodes.Types.Number;

import java.util.List;

public class TestVisitor extends Visitor<Void> {

    // -------------------------------------------------------------
    // Component declarations
    // -------------------------------------------------------------

    @Override
    public Void visit(ItemHeaderDeclaration itemHeaderDeclaration) {
        ComponentHeader header = itemHeaderDeclaration.getComponentHeader();

        String name = null;
        int line = -1;
        int portCount = 0;
        int componentItemCount = 0;
        int repeatCount = 0;   // <-- number of repeat loops in this componenttype

        // --- Header info: name, line, port count ---
        if (header != null) {
            if (header.getIdentifier() != null) {
                name = header.getIdentifier().getName();
                line = header.getIdentifier().getLine();
            }

            if (header.getListOfPortDeclarations() != null) {
                portCount = header.getListOfPortDeclarations().size();
            }
        }

        // --- Component items: count items AND repeat loops ---
        List<ComponentItem> componentItems = itemHeaderDeclaration.getComponentItemList();
        if (componentItems != null) {
            for (ComponentItem ci : componentItems) {
                if (ci == null) continue;
                componentItemCount++;

                if (ci instanceof RepeatLoop) {
                    repeatCount++;
                }
            }
        }

        // --- Print summary for this componenttype, including repeat count ---
        System.out.println(
                "Line: " + line +
                        " | Name: " + name +
                        " | Number of ports: " + portCount +
                        " | Number of component items: " + componentItemCount +
                        " | Number of repeat loops: " + repeatCount
        );

        // Visit header
        if (header != null) {
            header.accept(this);
        }

        // Visit component items
        if (componentItems != null) {
            for (ComponentItem componentItem : componentItems) {
                if (componentItem != null) {
                    componentItem.accept(this);
                }
            }
        }

        // Visit trailing componentName, if any (e.g., ": MyType")
        if (itemHeaderDeclaration.getComponentName() != null) {
            itemHeaderDeclaration.getComponentName().accept(this);
        }

        return null;
    }

    @Override
    public Void visit(ConfigHeaderDeclaration configHeaderDeclaration) {
        ConfigurationHeader header = configHeaderDeclaration.getConfigurationHeader();

        String name = null;
        int line = configHeaderDeclaration.getLine();
        int portCount = 0;
        int repeatCount = 0;
        int componentItemCount = 0;

        if (header != null) {
            if (header.getIdentifier() != null) {
                name = header.getIdentifier().getName();
                line = header.getIdentifier().getLine();
            }

            if (header.getListOfPortDeclarations() != null) {
                portCount = header.getListOfPortDeclarations().size();
            }
        }

        List<ComponentItem> componentItems = configHeaderDeclaration.getComponentItemList();
        if (componentItems != null) {
            for (ComponentItem ci : componentItems) {
                if (ci == null) continue;
                componentItemCount++;

                if (ci instanceof RepeatLoop) {
                    repeatCount++;
                }
            }
        }

        System.out.println(
                "Line: " + line +
                        " | Name: " + name +
                        " | Number of ports: " + portCount +
                        " | Number of component items: " + componentItemCount +
                        " | Number of repeat loops: " + repeatCount
        );

        // visit header
        if (header != null) {
            header.accept(this);
        }

        // visit component items
        if (componentItems != null) {
            for (ComponentItem componentItem : componentItems) {
                if (componentItem != null) {
                    componentItem.accept(this);
                }
            }
        }

        // visit trailing component name (if any)
        if (configHeaderDeclaration.getComponentName() != null) {
            configHeaderDeclaration.getComponentName().accept(this);
        }

        return null;
    }

    @Override
    public Void visit(ConfigDeclaration configDeclaration) {
        int repeatCount = 0;
        int componentItemCount = 0;
        String name = null;
        int line = configDeclaration.getLine();

        if (configDeclaration.getIdentifier() != null) {
            name = configDeclaration.getIdentifier().getName();
            line = configDeclaration.getIdentifier().getLine();
        }

        List<ComponentItem> componentItems = configDeclaration.getComponentItemList();
        if (componentItems != null) {
            for (ComponentItem ci : componentItems) {
                if (ci == null) continue;
                componentItemCount++;

                if (ci instanceof RepeatLoop) {
                    repeatCount++;
                }
            }
        }

        System.out.println(
                "Line: " + line +
                        " | Name: " + name +
                        " | Number of component items: " + componentItemCount +
                        " | Number of repeat loops: " + repeatCount
        );

        if (configDeclaration.getIdentifier() != null) {
            configDeclaration.getIdentifier().accept(this);
        }

        if (componentItems != null) {
            for (ComponentItem componentItem : componentItems) {
                if (componentItem != null) {
                    componentItem.accept(this);
                }
            }
        }

        if (configDeclaration.getComponentName() != null) {
            configDeclaration.getComponentName().accept(this);
        }

        return null;
    }

    // -------------------------------------------------------------
    // Generate region / generate items
    // -------------------------------------------------------------


    @Override
    public Void visit(LoopGenerateConstruct loopGenerateConstruct) {
        GenerateBlock gb = loopGenerateConstruct.getGenerateBlock();

        int generateItemCount = 0;
        int statementCount    = 0;

        if (gb != null) {
            if (gb instanceof DoGenerateBlock) {
                DoGenerateBlock dgb = (DoGenerateBlock) gb;
                List<GenerateItem> items = dgb.getGenerateItems();
                if (items != null) {
                    for (GenerateItem gi : items) {
                        if (gi != null) {
                            generateItemCount++;
                            statementCount++;
                        }
                    }
                }
            } else if (gb instanceof GenerateItem) {
                generateItemCount = 1;
                statementCount    = 1;
            }
        }

        // ------ NEW: find loop/generate-block name (e.g. GEN_FA) ------
        String name = null;
        if (gb instanceof DoGenerateBlock) {
            DoGenerateBlock dgb = (DoGenerateBlock) gb;

            if (dgb.getBeginGenerateBlockName() != null &&
                    dgb.getBeginGenerateBlockName().getIdentifier() != null) {
                name = dgb.getBeginGenerateBlockName()
                        .getIdentifier()
                        .getName();
            } else if (dgb.getGenerateBlockLabel() != null &&
                    dgb.getGenerateBlockLabel().getIdentifier() != null) {
                // fallback: label before 'do'
                name = dgb.getGenerateBlockLabel()
                        .getIdentifier()
                        .getName();
            }
        }

        // ------ CHANGED PRINT ------
        System.out.println(
                "Line: " + loopGenerateConstruct.getLine() +
                        " | Name: " + name +

                        " | Number of statements : " + statementCount
        );

        // normal traversal
        if (loopGenerateConstruct.getGenvarInitialization() != null) {
            loopGenerateConstruct.getGenvarInitialization().accept(this);
        }
        if (loopGenerateConstruct.getGenvarExpression() != null) {
            loopGenerateConstruct.getGenvarExpression().accept(this);
        }
        if (loopGenerateConstruct.getGenvarIteration() != null) {
            loopGenerateConstruct.getGenvarIteration().accept(this);
        }
        if (gb != null) {
            gb.accept(this);
        }

        return null;
    }


    // -------------------------------------------------------------
    // Component-program / interface instantiation
    // -------------------------------------------------------------
    @Override
    public Void visit(ComponentProgramInterfaceInstantiation inst) {
        // --- component type name & line ---
        String componentTypeName = null;
        int line = inst.getLine();

        if (inst.getIdentifier() != null) {
            componentTypeName = inst.getIdentifier().getName();
            line = inst.getIdentifier().getLine();
        }

        // --- instance names + port count ---
        int portCount = 0;
        java.util.List<String> instanceNames = new java.util.ArrayList<>();

        if (inst.getHierarchicalInstances() != null) {
            for (HierarchicalInstance hi : inst.getHierarchicalInstances()) {
                if (hi == null) continue;

                // instance name (u0, u1, ...)
                if (hi.getNameOfInstance() != null &&
                        hi.getNameOfInstance().getIdentifier() != null) {
                    instanceNames.add(hi.getNameOfInstance()
                            .getIdentifier()
                            .getName());
                }

                // ports
                portCount += hi.getNumOfPorts();
            }
        }

        String instancesStr = instanceNames.isEmpty()
                ? "<no instances>"
                : String.join(", ", instanceNames);

        // --- print summary ---
        System.out.println(
                "Line: " + line +
                        " | ComponentType: " + componentTypeName +
                        " | Instances: " + instancesStr +
                        " | Number of ports: " + portCount
        );

        // --- normal traversal below ---

        if (inst.getParameterValueAssignment() != null) {
            inst.getParameterValueAssignment().accept(this);
        }

        if (inst.getHierarchicalInstances() != null) {
            for (HierarchicalInstance hi : inst.getHierarchicalInstances()) {
                if (hi != null) {
                    hi.accept(this);
                }
            }
        }

        return null;
    }

}
