.class public Main
.super java/lang/Object

.field static a I
.field static b I
.field static n I

.method public static main([Ljava/lang/String;)V
    .limit stack 128
    .limit locals 128


    return
.end method