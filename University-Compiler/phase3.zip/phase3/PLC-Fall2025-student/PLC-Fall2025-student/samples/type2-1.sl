configuration T_Mixed_NoComponent;
    data int A = 4;
    data real B = 6.0;
    data signed int C = -3;

    data T1;
    data T2;
    data R;

    T1 = (A << 1) + (C & 1);
    T2 = (B / 2) + (A > C ? 1 : 0);
    R  = T1 + T2;

    repeat (1) period=1 display({A, B, C});
    repeat (1) period=1 display({T1});
    repeat (1) period=1 display({T2});
    repeat (1) period=1 display({R});
endconfiguration