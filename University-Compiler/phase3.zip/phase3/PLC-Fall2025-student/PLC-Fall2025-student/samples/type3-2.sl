componenttype Calc
    port in int a;
    port in int b;
    port in int c;
    port out int r;
;
    r = a + b * c - (a << 1);
endcomponenttype:Calc

configuration T_Component_Int_Expr;
    data int x = 2;
    data int y = 3;
    data int z = 4;
    data int res = 0;

    Calc u(.a(x), .b(y), .c(z), .r(res));

    display({res});
endconfiguration
