configuration Scheduler_Dep_1;
    data int a = 0;
    data int b = 1;
    data int c = 0;

    repeat (6) period=1 c = a + b;
    repeat (6) period=1 a = b;
    repeat (6) period=1 b = c;
    repeat (6) period=1 display({a, b, c});
endconfiguration
