configuration T_Mixed_NoComponent_AssignPromotion;
    data int        a = 2;
    data integer    b = 5;
    data real       c = 1.25;
    data shortreal  d = 0.0;

    c = a + b * c;
    d = c - a / 2;
    b = d + a;
    a = b * 2;

    display({a, b, c, d});
endconfiguration