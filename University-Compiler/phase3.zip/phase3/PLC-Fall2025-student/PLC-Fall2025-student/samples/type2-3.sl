configuration T_Mixed_NoComponent_Bitwise_And_Real;
    data int   x = 7;
    data int   y = 0;
    data real  r = 1.5;

    y = (x & 1) == 1 ? x >> 1 : x << 1;
    r = r * y + 0.5;

    display({x, y, r});
endconfiguration
