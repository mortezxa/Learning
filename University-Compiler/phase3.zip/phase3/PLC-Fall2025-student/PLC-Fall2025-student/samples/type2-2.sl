configuration T_Mixed_NoComponent_Arithmetic;
    data int        i = 4;
    data integer    j = 3;
    data shortreal  s = 2.5;
    data real       r = 0.0;

    r = i * j + s;
    s = r / 2;
    j = i + j * 2;
    i = j - 1;

    display({i, j, s, r});
endconfiguration
