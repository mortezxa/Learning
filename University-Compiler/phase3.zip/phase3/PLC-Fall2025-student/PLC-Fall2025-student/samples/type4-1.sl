componenttype InnerCalc(input x, input y)
    out out;
    out = ((x + 1) * 2) + (y / 2);
endcomponenttype

componenttype OuterCalc(input a, input b, input c)
    out out;
    out = (InnerCalc(a, b) << 1) + (c & 3);
endcomponenttype

configuration T_Component_Deep1;
    data int A = 2;
    data real B = 4.0;
    data signed int C = -2;

    data T1;
    data R;

    T1 = (A * 2) + (C % 3);
    R  = OuterCalc(A, B, C);

    repeat (1) period=1 display({A, B, C});
    repeat (1) period=1 display({T1});
    repeat (1) period=1 display({R});
endconfiguration
