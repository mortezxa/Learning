configuration T_Scheduler_Only2;
    data int X = 5;
    data int Y = 2;
    data Z;

    Z = (X > Y) ? ((X * 2) + (Y << 1)) : ((Y * 2) + X);

    repeat (1) period=1 display({X});
    repeat (1) period=1 display({Y});
    repeat (1) period=1 display({Z});
endconfiguration
