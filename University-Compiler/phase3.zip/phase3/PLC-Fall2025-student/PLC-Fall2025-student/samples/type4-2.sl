componenttype Scale(input r)
    out out;
    out = (r > 0) ? ((r + 1) * 3) : ((r - 1) * 2);
endcomponenttype

componenttype Finalize(input x)
    out out;
    out = (x & 1) == 0 ? (x >> 1) : (x + 5);
endcomponenttype

configuration T_Component_Deep2;
    data signed int A = -1;
    data int B = 3;

    data S;
    data R1;
    data R;

    S  = A + B;
    R1 = Scale(S);
    R  = Finalize(R1);

    repeat (1) period=1 display({A, B});
    repeat (1) period=1 display({S});
    repeat (1) period=1 display({R1});
    repeat (1) period=1 display({R});
endconfiguration
