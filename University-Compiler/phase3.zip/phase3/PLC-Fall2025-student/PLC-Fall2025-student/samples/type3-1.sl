componenttype AddMul
    port in int a;
    port in int b;
    port out int r;
;
    r = (a + b) * 2;
endcomponenttype:AddMul

componenttype Combine
    port in int x;
    port in int y;
    port out int z;
;
    AddMul u1(.a(x), .b(y), .r(z));
endcomponenttype:Combine

configuration T_Component_Int_Nested;
    data int p = 3;
    data int q = 4;
    data int out = 0;

    Combine c1(.x(p), .y(q), .z(out));

    display({out});
endconfiguration