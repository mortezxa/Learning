componenttype Inc
    port in int a;
    port out int r;
;
    r = a + 1;
endcomponenttype:Inc

componenttype Double
    port in int x;
    port out int y;
;
    y = x * 2;
endcomponenttype:Double

configuration T_Component_Int_Chain;
    data int v = 5;
    data int t1 = 0;
    data int t2 = 0;

    Inc    u1(.a(v),  .r(t1));
    Double u2(.x(t1), .y(t2));

    display({t2});
endconfiguration
