package main.scheduler;

import main.ast.nodes.ComponentItem.LoopStatement.StatementOrNull;

import java.util.ArrayList;

public class ScheduledEvent {
    private final long time;
    private final StatementOrNull statement;


    public ScheduledEvent(long time, StatementOrNull statement) {
        this.time = time;
        this.statement = statement;
    }

    public long getTime() { return time; }
    public StatementOrNull getStatement() { return statement; }
}
