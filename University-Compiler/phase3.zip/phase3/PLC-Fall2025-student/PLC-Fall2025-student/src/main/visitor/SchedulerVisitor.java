package main.visitor;

import main.TypeCheck.Type;
import main.ast.nodes.ComponentItem.LoopStatement.RepeatLoop;
import main.scheduler.ScheduledEvent;

import java.util.ArrayList;
import java.util.List;

public class SchedulerVisitor extends Visitor<Type>{
    ArrayList<ScheduledEvent> eventQueue = new ArrayList<>();

    public List<ScheduledEvent> getEventQueue() {
        return eventQueue;
    }

    @Override
    public Type visit(RepeatLoop repNode) {
        return null;
    }

}