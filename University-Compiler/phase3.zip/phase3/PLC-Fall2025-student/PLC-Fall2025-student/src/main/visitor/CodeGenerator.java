package main.visitor;

import main.ast.nodes.ComponentDeclaration.ConfigHeaderDeclaration;
import main.ast.nodes.SourceText;
import main.ast.nodes.ComponentDeclaration.ComponentDeclaration;
import main.ast.nodes.ComponentItem.ComponentItem;
import main.ast.nodes.ComponentItem.NetDeclaration.*;
import main.ast.nodes.ComponentItem.LoopStatement.StatementOrNull;
import main.ast.nodes.Expression.*;
import main.scheduler.ScheduledEvent;

import java.io.*;
import java.util.ArrayList;

public class CodeGenerator extends Visitor<String> {
    private final String outputPath;
    private FileWriter writer;
    private final ArrayList<ScheduledEvent> eventQueue;

    public CodeGenerator(ArrayList<ScheduledEvent> eventQueue) {
        this.outputPath = "./codeGenOutput/";
        this.eventQueue = eventQueue;
        prepareOutputDirectory();
    }

    private void prepareOutputDirectory() {
        File dir = new File(outputPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }


    @Override
    public String visit(SourceText sourceText) {
        try {
            initializeWriter();
            writeClassHeader();
            writeStaticFields(sourceText);
            writeMainMethodHeader();
            generateSimulationCode();
            writeMainMethodFooter();
            closeWriter();
        } catch (IOException e) {}
        return null;
    }


    private void initializeWriter() throws IOException {
        writer = new FileWriter(outputPath + "Main.j");
    }

    private void writeClassHeader() throws IOException {
        writer.write(".class public Main\n");
        writer.write(".super java/lang/Object\n\n");
    }

    private void writeStaticFields(SourceText sourceText) throws IOException {
        for (ComponentDeclaration cd : sourceText.getComponentDeclarationList()) {
            if (cd instanceof ConfigHeaderDeclaration) {
                visitComponentForFields((ConfigHeaderDeclaration) cd);
            }
        }
        writer.write("\n");
    }

    private void writeMainMethodHeader() throws IOException {
        writer.write(".method public static main([Ljava/lang/String;)V\n");
        writer.write("    .limit stack 128\n");
        writer.write("    .limit locals 128\n\n");
    }

    private void generateSimulationCode() throws IOException {
        for (ScheduledEvent event : eventQueue) {
            StatementOrNull stmt = event.getStatement();
            String bytecode = stmt.accept(this);
            if (bytecode != null) {
                writer.write(bytecode);
            }
        }
    }

    private void writeMainMethodFooter() throws IOException {
        writer.write("\n    return\n");
        writer.write(".end method\n");
    }

    private void closeWriter() throws IOException {
        writer.close();
    }

    private void visitComponentForFields(ConfigHeaderDeclaration cd) {
        if (cd.getComponentItemList() != null) {
            for (ComponentItem item : cd.getComponentItemList()) {
                if (item instanceof NetTypeNetDeclaration) {
                    ((NetTypeNetDeclaration) item).accept(this);
                }
            }
        }
    }

    @Override
    public String visit(NetTypeNetDeclaration netDecl) {
        // ToDo: Generate .field instructions
        return null;
    }

    @Override
    public String visit(NonEmptyStatementOrNull stmt) {
        // ToDo: Delegate to inner statement
        return null;
    }
}