package main.ast.nodes.ComponentItem.LoopStatement;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class StatementOrNull extends Node {

}
