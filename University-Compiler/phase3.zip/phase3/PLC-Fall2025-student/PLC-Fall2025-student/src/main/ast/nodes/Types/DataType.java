package main.ast.nodes.Types;

import main.ast.nodes.Expression.ParamExpression;

public abstract class DataType extends ParamExpression {
    public DataType() {

    }
}
