package main.ast.nodes.ListOfParameterAssignments;

import main.ast.nodes.Node;

public abstract class ListOfParameterAssignments extends Node {

    public ListOfParameterAssignments() {
    }

}
