package main.ast.nodes.ComponentDeclaration;


import main.ast.nodes.ComponentName;
import main.ast.nodes.Headers.ComponentHeader;
import main.ast.nodes.Identifier;
import main.visitor.IVisitor;

import java.util.List;

public class IdentifierComponent extends ComponentDeclaration {
    public IdentifierComponent() {
    }


    public void setComponentName(ComponentName componentName) {
        this.componentName = componentName;
    }

    private ComponentName componentName;
    private List<ComponentItem> componentItemList;
    public void  addComponentItem(ComponentItem componentItem){componentItemList.add(componentItem);}

    public void setIdentifier(Identifier identifier) {
        this.identifier = identifier;
    }

    // private ComponentItem componentItem;
    private Identifier identifier;
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
