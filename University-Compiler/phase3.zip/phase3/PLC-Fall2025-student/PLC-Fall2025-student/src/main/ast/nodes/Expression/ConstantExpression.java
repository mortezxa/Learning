package main.ast.nodes.Expression;

import main.ast.nodes.ComponentItem.GenvarExpression;
import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class ConstantExpression  extends GenvarExpression {


    public ConstantExpression() {
    }
}
