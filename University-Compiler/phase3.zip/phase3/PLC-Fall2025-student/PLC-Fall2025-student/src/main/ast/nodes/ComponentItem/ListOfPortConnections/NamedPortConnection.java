package main.ast.nodes.ComponentItem.ListOfPortConnections;



import main.ast.nodes.Node;

public abstract class NamedPortConnection extends Node {
    // Common base for all named port connection variants
}

