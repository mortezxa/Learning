package main.ast.nodes;

import main.visitor.IVisitor;

public class ComponentName extends  Node{
    public ComponentName() {

    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
