package main.ast.nodes;

<<<<<<< HEAD
import main.ast.nodes.Types.SimpleType;
import main.visitor.IVisitor;

public class Identifier extends SimpleType {
    private String name;
    public Identifier(String name,int line) {
        this.name=name;
        this.setLine(line);
    }
    public String getName() {
        return name;
    }
    public void setName(String new_name) {
        this.name = new_name;
    }


=======
import main.visitor.IVisitor;

public class Identifier extends Node {
    public Identifier(String name,int line) {
         this.name=name;
        this.line=line;
    }
    int line;
    String name;
>>>>>>> c23ca41 (start ast)
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
