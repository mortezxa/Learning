package main.ast.nodes.ParameterPortList;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public class ParameterBased extends Node {
    public ParameterBased() {

    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
