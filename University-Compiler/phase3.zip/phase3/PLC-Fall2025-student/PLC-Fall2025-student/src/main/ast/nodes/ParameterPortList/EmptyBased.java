package main.ast.nodes.ParameterPortList;

<<<<<<< HEAD
import main.visitor.IVisitor;

public class EmptyBased extends ParameterPortList {

    public EmptyBased() {

    }

=======
import main.ast.nodes.Node;
import main.visitor.IVisitor;

public class EmptyBased extends Node {
    public EmptyBased() {

    }
>>>>>>> c23ca41 (start ast)
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
<<<<<<< HEAD
=======

>>>>>>> c23ca41 (start ast)
}
