package main.ast.nodes;

public abstract class DataDec extends Node {

    public String getName()
    {
        return "";
    }
}
