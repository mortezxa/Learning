package main.ast.nodes;

import main.ast.nodes.ComponentDeclaration.ComponentDeclaration;
<<<<<<< HEAD
import main.symbolTable.SymbolTable;
=======
>>>>>>> c23ca41 (start ast)
import main.visitor.IVisitor;

import java.util.List;
import java.util.ArrayList;

public class SourceText extends Node{
<<<<<<< HEAD

    private SymbolTable symbolTable;

    public SymbolTable getSymbolTable() {
        return symbolTable;
    }

    public void setSymbolTable(SymbolTable symbolTable) {
        this.symbolTable = symbolTable;
    }

    public List<ComponentDeclaration> getComponentDeclarationList() {
        return componentDeclarationList;
    }

=======
>>>>>>> c23ca41 (start ast)
    List<ComponentDeclaration> componentDeclarationList;

    public SourceText() {
        this.componentDeclarationList = new ArrayList<>();
    }

    public void addComponentDeclaration(ComponentDeclaration componentDeclaration) {
        componentDeclarationList.add(componentDeclaration);
    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
