package main.ast.nodes.Types;

public enum Signing {
    SIGNED,
    UNSIGNED,
}
