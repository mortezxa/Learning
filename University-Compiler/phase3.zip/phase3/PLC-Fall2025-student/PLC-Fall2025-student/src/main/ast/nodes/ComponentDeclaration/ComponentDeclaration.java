package main.ast.nodes.ComponentDeclaration;
<<<<<<< HEAD
import main.ast.nodes.ComponentItem.*;
import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class ComponentDeclaration extends ComponentItem {

    public ComponentDeclaration() {
    }

    public void setEndLine(int endLine) {
        this.endLine = endLine;
    }

    public void setStartLine(int startLine) {
        this.startLine = startLine;
    }

    private int endLine=0;
    private int startLine=0;
=======

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class ComponentDeclaration extends Node {

    public ComponentDeclaration() {
    }
  //  public abstract
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }

>>>>>>> c23ca41 (start ast)
}
