package main.ast.nodes.Types;

/**
 * Base class for non_integer_type:
 *   shortreal, real
 */
public enum NonIntegerType{
    SHORT_REAL,
    REAL,
}
