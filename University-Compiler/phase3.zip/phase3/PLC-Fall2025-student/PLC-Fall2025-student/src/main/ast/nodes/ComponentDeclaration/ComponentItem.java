package main.ast.nodes.ComponentDeclaration;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public class ComponentItem extends Node {
    public ComponentItem() {
    }
    @Override
    public <T> T accept(IVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
