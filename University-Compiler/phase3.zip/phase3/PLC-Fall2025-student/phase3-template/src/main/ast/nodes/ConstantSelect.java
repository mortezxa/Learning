package main.ast.nodes;

import main.ast.nodes.Node;
import main.visitor.IVisitor;

public abstract class ConstantSelect extends Node {

    public ConstantSelect() {
        super();
    }
}