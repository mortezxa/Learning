package main.ast.nodes.ComponentItem.LoopStatement;

import main.ast.nodes.ComponentItem.ComponentItem;
import main.visitor.IVisitor;

public abstract class LoopStatement extends ComponentItem {

    public LoopStatement() {
    }

}
