package main.ast.nodes.Expression;

import main.visitor.IVisitor;

/**
 * Base class for all constant primaries.
 * Built by the `constant_primary` rule.
 */
public abstract class ConstantPrimary extends ConstantExpression {

}
