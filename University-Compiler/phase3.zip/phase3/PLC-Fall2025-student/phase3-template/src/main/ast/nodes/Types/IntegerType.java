package main.ast.nodes.Types;

public enum IntegerType {
    BIT,
    DATA,
    BYTE,
    SHORT_INT,
    INT,
    LONG_INT,
    INTEGER,
    TIME,
}
