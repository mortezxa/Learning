package main.ast.nodes;

import main.ast.nodes.ComponentItem.GenerateItem.GenerateItem;

public class EmptyGenerateItem extends GenerateItem {
}
