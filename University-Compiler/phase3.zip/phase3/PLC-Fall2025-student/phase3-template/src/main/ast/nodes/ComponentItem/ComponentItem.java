package main.ast.nodes.ComponentItem;

import main.ast.nodes.*;
import main.ast.nodes.Expression.StatementItem;
import main.visitor.IVisitor;

public abstract class ComponentItem extends StatementItem {

    public ComponentItem() {

    }

    public ComponentItem(int line) {

    }
}
